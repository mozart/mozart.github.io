// Copyright (c) by Denys Duchier, Dec 1999, Universitaet des Saarlandes
#include <mozart.h>
#include <xmlparse.h>
#include <string.h>

class OZ_XML_PARSER: public OZ_Extension {
private:
  XML_Parser parser;
  OZ_Term events;
  void pushEvent(OZ_Term e);
  void signalEvent(OZ_Term label);
  void signalEvent(OZ_Term label,OZ_Term arg1);
  void signalEvent(OZ_Term label,OZ_Term arg1,OZ_Term arg2);
private:
  OZ_XML_PARSER(XML_Parser pa,OZ_Term es)
    :OZ_Extension(),parser(pa),events(es){}
public:
  OZ_XML_PARSER(int);
  static int id;
  friend int oz_isXMLparser(OZ_Term);
  virtual int getIdV() { return id; }
  virtual OZ_Term typeV() { return OZ_atom("expat"); }
  virtual OZ_Term printV(int depth = 10);
  virtual OZ_Extension* gCollectV(void);
  virtual OZ_Extension* sCloneV(void) { Assert(0); return NULL; }
  virtual void gCollectRecurseV(void);
  virtual void sCloneRecurseV(void) {}
  //
  int closed() { return parser==0; }
  void close();
  ////////////////////////////////////////////////////////////////////
  void startElementMethod(const XML_Char *name,
			   const XML_Char **atts);
  void endElementMethod(const XML_Char *name);
  void characterDataMethod(const XML_Char *s,int len);
  void processingInstructionMethod(const XML_Char *target,
				    const XML_Char *data);
  void commentMethod(const XML_Char *data);
  void startCdataSectionMethod();
  void endCdataSectionMethod();
  void defaultMethod(const XML_Char *s,int len);
  void startNamespaceDeclMethod(const XML_Char*,
				const XML_Char*);
  void endNamespaceDeclMethod(const XML_Char*);
  int nextParse(char*buf,int len,int isFinal) {
    return XML_Parse(parser,buf,len,isFinal);
  }
  const char* errorString() {
    return XML_ErrorString(XML_GetErrorCode(parser));
  }
  int currentLine() {
    return XML_GetCurrentLineNumber(parser);
  }
  OZ_Term getEvents() {
    OZ_Term l = OZ_nil();
    if (events) {
      while (!OZ_isNil(events)) {
	l=OZ_cons(OZ_head(events),l);
	events=OZ_tail(events);
      }
      events=0;
    }
    return l;
  }
};

int OZ_XML_PARSER::id;

inline int oz_isXMLparser(OZ_Term t)
{
  t = OZ_deref(t);
  return OZ_isExtension(t) &&
    OZ_getExtension(t)->getIdV()==OZ_XML_PARSER::id;
}

inline OZ_XML_PARSER* tagged2XMLparser(OZ_Term t)
{
  Assert(oz_isXMLparser(t));
  return (OZ_XML_PARSER*) OZ_getExtension(OZ_deref(t));
}

#define expatARGS OZ_inAsList()
#define expatException(PROC,MSG) \
OZ_raiseC("expat",3,OZ_atom(PROC),expatARGS,OZ_atom(MSG))
#define expatError(PROC,MSG) \
OZ_raiseErrorC("expat",3,OZ_atom(PROC),expatARGS,OZ_atom(MSG))
#define OZ_declareExpat(ARG,VAR,METH,CHECK) \
OZ_declareType(ARG,VAR,OZ_XML_PARSER*,"expat",oz_isXMLparser,tagged2XMLparser); \
if (CHECK && VAR->closed()) return expatError(METH,"alreadyClosed");
#define OZ_declareTermPort(ARG,VAR,METH) \
OZ_declareType(ARG,VAR,OZ_Term,"expat",OZ_isPort,);

OZ_Term OZ_XML_PARSER::printV(int depth = 10)
{
  return OZ_mkTupleC("#",3,
		     OZ_atom("<"),
		     typeV(),
		     OZ_atom(">"));
}

void  OZ_XML_PARSER::pushEvent(OZ_Term e)
{
  if (events==0) events=OZ_nil();
  events=OZ_cons(e,events);
}

void OZ_XML_PARSER::signalEvent(OZ_Term label)
{
  pushEvent(label);
}

void OZ_XML_PARSER::signalEvent(OZ_Term label,OZ_Term arg1)
{
  pushEvent(OZ_mkTuple(label,1,arg1));
}

void OZ_XML_PARSER::signalEvent(OZ_Term label,OZ_Term arg1,OZ_Term arg2)
{
  pushEvent(OZ_mkTuple(label,2,arg1,arg2));
}

OZ_Extension* OZ_XML_PARSER::gCollectV(void)
{
  return (new OZ_XML_PARSER(parser,events));
}

void OZ_XML_PARSER::gCollectRecurseV(void) {
  if (events) OZ_gCollect(&events);
  // update internal reference, since `this' pointer has
  // changed uring GC
  XML_SetUserData(parser,this);
}

//////////////////////////////////////////////////////////////////////

static void startElementHandler(void*userData,
				const XML_Char *name,
				const XML_Char **atts)
{
  ((OZ_XML_PARSER*)userData)->startElementMethod(name,atts);
}

static void endElementHandler(void*userData,
			      const XML_Char *name)
{
  ((OZ_XML_PARSER*)userData)->endElementMethod(name);
}

static void characterDataHandler(void*userData,
				 const XML_Char *s,
				 int len)
{
  ((OZ_XML_PARSER*)userData)->characterDataMethod(s,len);
}

static void processingInstructionHandler(void*userData,
					 const XML_Char *target,
					 const XML_Char *data)
{
  ((OZ_XML_PARSER*)userData)->processingInstructionMethod(target,data);
}

static void commentHandler(void*userData,
			   const XML_Char *data)
{
  ((OZ_XML_PARSER*)userData)->commentMethod(data);
}

static void startCdataSectionHandler(void*userData)
{
  ((OZ_XML_PARSER*)userData)->startCdataSectionMethod();
}

static void endCdataSectionHandler(void*userData)
{
  ((OZ_XML_PARSER*)userData)->endCdataSectionMethod();
}

static void defaultHandler(void *userData,
			   const XML_Char *s,
			   int len)
{
  ((OZ_XML_PARSER*)userData)->defaultMethod(s,len);
}

static void startNamespaceDeclHandler(void*userData,
				      const XML_Char *prefix,
				      const XML_Char *uri)
{
  ((OZ_XML_PARSER*)userData)->startNamespaceDeclMethod(prefix,uri);
}

static void endNamespaceDeclHandler(void*userData,
				    const XML_Char *prefix)
{
  ((OZ_XML_PARSER*)userData)->endNamespaceDeclMethod(prefix);
}

//////////////////////////////////////////////////////////////////////

inline char* unConst(const char* s)
{
  union {
    const char *a;
    char *b;
  } v;
  v.a = s;
  return v.b;
}

inline OZ_mkByteString(const char*s) {
  return OZ_mkByteString(unConst(s),strlen(s));
}

static OZ_Term eventStartElement;

void OZ_XML_PARSER::startElementMethod(const XML_Char *name,
				       const XML_Char **atts)
{
  OZ_Term l = OZ_nil();
  while (*atts) {
    OZ_Term key = OZ_atom(atts[0]);
    OZ_Term val = OZ_mkByteString(atts[1]);
    l = OZ_cons(OZ_pair2(key,val),l);
    atts += 2;
  }
  signalEvent(eventStartElement,OZ_atom(name),l);
}

static OZ_Term eventEndElement;

void OZ_XML_PARSER::endElementMethod(const XML_Char *name)
{
  signalEvent(eventEndElement,OZ_atom(name));
}

static OZ_Term eventCharacterData;

void OZ_XML_PARSER::characterDataMethod(const XML_Char *s,int len)
{
  signalEvent(eventCharacterData,OZ_mkByteString(unConst(s),len));
}

static OZ_Term eventProcessingInstruction;

void OZ_XML_PARSER::processingInstructionMethod(const XML_Char *target,
						const XML_Char *data)
{
  signalEvent(eventProcessingInstruction,OZ_atom(target),OZ_mkByteString(data));
}

static OZ_Term eventComment;

void OZ_XML_PARSER::commentMethod(const XML_Char *data)
{
  signalEvent(eventComment,OZ_mkByteString(data));
}

static OZ_Term eventStartCdataSection;

void OZ_XML_PARSER::startCdataSectionMethod()
{
  signalEvent(eventStartCdataSection);
}

static OZ_Term eventEndCdataSection;

void OZ_XML_PARSER::endCdataSectionMethod()
{
  signalEvent(eventEndCdataSection);
}

static OZ_Term eventDefault;

void OZ_XML_PARSER::defaultMethod(const XML_Char *s,int len)
{
  signalEvent(eventDefault,OZ_mkByteString((char*)s,len));
}

static OZ_Term eventStartNamespaceDecl;

void OZ_XML_PARSER::startNamespaceDeclMethod(const XML_Char* prefix,
					     const XML_Char* uri)
{
  signalEvent(eventStartNamespaceDecl,
	      OZ_atom(prefix?prefix:""),
	      OZ_atom(uri?uri:""));
}

static OZ_Term eventEndNamespaceDecl;

void OZ_XML_PARSER::endNamespaceDeclMethod(const XML_Char* prefix)
{
  signalEvent(eventEndNamespaceDecl,
	      OZ_atom(prefix?prefix:""));
}

void OZ_XML_PARSER::close()
{
  if (parser!=0) {
      XML_ParserFree(parser);
      parser=0;
      events=0;
    }
}

//////////////////////////////////////////////////////////////////////

OZ_XML_PARSER::OZ_XML_PARSER(int c):OZ_Extension(),events(0) {
  parser = (c<0)?XML_ParserCreate(NULL):XML_ParserCreateNS(NULL,c);
  XML_SetUserData(parser,this);
  XML_SetElementHandler(parser,
			startElementHandler,
			endElementHandler);
  XML_SetCharacterDataHandler(parser,
			      characterDataHandler);
  XML_SetProcessingInstructionHandler(parser,
				      processingInstructionHandler);
  XML_SetCommentHandler(parser,
			commentHandler);
  XML_SetCdataSectionHandler(parser,
			     startCdataSectionHandler,
			     endCdataSectionHandler);
  XML_SetDefaultHandler(parser,
			defaultHandler);
  XML_SetNamespaceDeclHandler(parser,
			      startNamespaceDeclHandler,
			      endNamespaceDeclHandler);
}

//////////////////////////////////////////////////////////////////////

OZ_BI_define(expat_new,1,1)
{
  OZ_declareInt(0,c);
  OZ_RETURN(OZ_extension(new OZ_XML_PARSER(c)));
}
OZ_BI_end

OZ_BI_define(expat_close,1,0)
{
  OZ_declareExpat(0,x,"close",0);
  x->close();
  return PROCEED;
}
OZ_BI_end

OZ_BI_define(expat_next,3,1)
{
  OZ_declareExpat(0,x,"next",1);
  OZ_declareVS(1,buf,len);
  OZ_declareBool(2,isFinal);
  if (!x->nextParse(buf,len,isFinal)) {
    return OZ_raiseErrorC("expat",3,OZ_atom("next"),
			  OZ_atom(x->errorString()),
			  OZ_int(x->currentLine()));
  }
  OZ_Term l = x->getEvents();
  if (isFinal) x->close();
  OZ_RETURN(l);
}
OZ_BI_end

//////////////////////////////////////////////////////////////////////

#define NEWSYM(V,S) V=OZ_atom(S); OZ_protect(&V);

OZ_C_proc_interface * oz_init_module(void)
{
  static OZ_C_proc_interface table[] = {
    {"new",1,1,expat_new},
    {"close",1,0,expat_close},
    {"next",3,1,expat_next},
    {0,0,0,0}
  };
  NEWSYM(eventStartElement,"startElement");
  NEWSYM(eventEndElement,"endElement");
  NEWSYM(eventCharacterData,"characters");
  NEWSYM(eventProcessingInstruction,"processingInstruction");
  NEWSYM(eventComment,"comment");
  NEWSYM(eventStartCdataSection,"startCDATA");
  NEWSYM(eventEndCdataSection,"endCDATA");
  NEWSYM(eventDefault,"default");
  NEWSYM(eventStartNamespaceDecl,"startNamespaceDeclScope");
  NEWSYM(eventEndNamespaceDecl,"endNamespaceDeclScope");
  OZ_XML_PARSER::id = oz_newUniqueId();
  return table;
}

char oz_module_name[] = "expat";
