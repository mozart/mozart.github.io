#include "mozart_cpi.hh"
#include "mozart_cpi_extra.hh"

class AllDisjointPropagator: public OZ_Propagator {
private:
  static OZ_PropagatorProfile profile;
  int _n;
  OZ_FSetValue _u;
  OZ_Term * _v;
public:
  AllDisjointPropagator(OZ_Term v)
    : OZ_Propagator(),_n(OZ_vectorSize(v)),_u(fs_empty)
  {
    _v =  OZ_hallocOzTerms(_n);
    OZ_getOzTermVector(v, _v);
  }

  virtual OZ_Return propagate(void);
                              
  virtual size_t sizeOf(void) {  
    return sizeof(AllDisjointPropagator);
  }
  virtual OZ_PropagatorProfile *getProfile(void) const {  
    return &profile;  
  }
  virtual OZ_Term getParameters(void) const;
  virtual void gCollect(void);
  virtual void sClone(void);
};
                              
OZ_PropagatorProfile AllDisjointPropagator::profile = "fset_all_disjoint";

OZ_Term AllDisjointPropagator::getParameters(void) const {
  OZ_Term list = OZ_nil();
                                
  for (int i = _n; i--; )
    list = OZ_cons(_v[i], list);

  return list;
}

void AllDisjointPropagator::gCollect(void)
{
  _v = OZ_gCollectAllocBlock(_n,_v);
  _u.copyExtension();
}

void AllDisjointPropagator::sClone(void)
{
  _v = OZ_sCloneAllocBlock(_n,_v);
  _u.copyExtension();
}

class AllDisjointExpects2 : public OZ_Expect {
public:
  OZ_expect_t expectFS(OZ_Term t) { 
    return expectFSetVar(t, fs_prop_bounds); 
  }
  OZ_expect_t expectFSVector(OZ_Term t) {
    return expectVector(t, (OZ_ExpectMeth) &expectFS);
  }
};

OZ_BI_define(fset_all_disjoint, 1, 0)
{
  OZ_EXPECTED_TYPE(OZ_EM_VECT OZ_EM_FSET);
                              
  AllDisjointExpects2 pe;
  OZ_EXPECT(pe,0,expectFSVector);
                              
  return pe.impose(new AllDisjointPropagator(OZ_in(0)));
}
OZ_BI_end

OZ_Return AllDisjointPropagator::propagate(void)
{
  OZ_FSetVar v[_n];
  OZ_FSetVar_Iterator v_iter(_n,v);
  v_iter.read(_v);

  // first, we discover all equal variables and
  // force them to be empty

  int * is = OZ_findEqualVars(_n,_v);

  for (int i=_n;i--;) {
    int j = is[i];
    if (j >= 0 &&		// is a variable
	j < i  &&		// occured previously at j
	is[j] >= 0		// has not been emptied yet
	)
      {
	is[j] = -2;
	if (!(*v[j] <= fs_empty)) goto failure;
      }
  }

  OZ_FSetValue u = _u;
  // check that glb(Si)||glb(Sj) for i!=j
  // and accumulate glbs
  for (int i=_n;i--;) {
    OZ_FSetValue glb_i(v[i]->getGlbSet());
    if (!(*v[i] != u)) goto failure;
    u |= glb_i;
  }
  // here u=glb(S1)|...|glb(Sn)

  // we maintain the invariants
  // (1) glb(Si)||glb(Sj) for i!=j
  // (2) u=glb(S1)|...|glb(Sn)

  int again;
  do {
    again = 0;
    for (int i=_n;i--;) {
      // at each step we remove from Si i.e. from lub(Si)
      // all elements that are in u but not in glb(Si)
      // i.e. which are known to be in some other Sj
      // this can only modify Si.  due to cardinality
      // constraints modifying lub(Si) may also modify
      // glb(Si).
      int card_before = v[i]->getKnownIn();
      // remove all elements known to be in other sets
      if (!(*v[i] != (u - v[i]->getGlbSet()))) goto failure;
      // did this modify glb(Si)?
      if (v[i]->getKnownIn() != card_before) {
	// this can only have added elements to glb(Si)
	// that are not known to be in other sets, i.e.
	// that are not in u.  At this point, it is still
	// the case that glb(Si)||glb(Sj) for i!=j, and
	// we must restablish u=glb(S1)|...|glb(Sn)
	u |= v[i]->getGlbSet();
	// u has been modified, we must iterate again
	again=1;
      }
    }
  }
  while (again);

  // is the constraint entailed? i.e. are all sets
  // necessarily disjoint? i.e. are their lubs disjoint.
  // at the same time, also drop vars that have become
  // determined and accumulate their union in _u

  {
    int entailed=1;
    int j=0;
    // doesn't need to be initialized with _u because
    // _u has been removed from the lubs of all vars
    OZ_FSetValue union_lubs(fs_empty);

    for (int i=0;i<_n;i+=1) {
      if (entailed) {
	OZ_FSetValue lub_i(v[i]->getLubSet());
	if ((entailed = ((union_lubs & lub_i).getCard() == 0)))
	    union_lubs |= lub_i;
      }
      if (v[i]->isValue()) {
	_u |= v[i]->getGlbSet();
	continue;
      }
      // trust Tobias that this actually works
      _v[j] = _v[i];
      j += 1;
    }
    _n = j;
    v_iter.leave();
    return (entailed)?OZ_ENTAILED:OZ_SLEEP;
  }
  
 failure:
  v_iter.fail();
  return OZ_FAILED;
}

OZ_BI_proto(fset_all_disjoint);

OZ_C_proc_interface *oz_init_module(void)
{
  static OZ_C_proc_interface table[] = {
    {"all_disjoint", 1, 0, fset_all_disjoint},
    {0, 0, 0, 0}
  };
  return table;
}
