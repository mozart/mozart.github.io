#include "mozart_cpi.hh"
#include "mozart_cpi_extra.hh"

class AllDisjointPropagator: public OZ_Propagator {
private:
  static OZ_PropagatorProfile profile;
  int _n;
  OZ_Term * _v;
public:
  AllDisjointPropagator(OZ_Term v)
    : _n(OZ_vectorSize(v))
  {
    _v =  OZ_hallocOzTerms(_n);
    OZ_getOzTermVector(v, _v);
  }

  virtual OZ_Return propagate(void);
                              
  virtual size_t sizeOf(void) {  
    return sizeof(AllDisjointPropagator);
  }
  virtual OZ_PropagatorProfile *getProfile(void) const {  
    return &profile;  
  }
  virtual OZ_Term getParameters(void) const;
  virtual void gCollect(void);
  virtual void sClone(void);
};
                              
OZ_PropagatorProfile AllDisjointPropagator::profile;

OZ_Term AllDisjointPropagator::getParameters(void) const {
  OZ_Term list = OZ_nil();
                                
  for (int i = _n; i--; )
    list = OZ_cons(_v[i], list);

  return list;
}

void AllDisjointPropagator::gCollect(void)
{
  _v = OZ_gCollectAllocBlock(_n,_v);
}

void AllDisjointPropagator::sClone(void)
{
  _v = OZ_sCloneAllocBlock(_n,_v);
}

class AllDisjointExpect : public OZ_Expect {
public:
  OZ_expect_t expectFS(OZ_Term t) { 
    return expectFSetVar(t, fs_prop_bounds); 
  }
  OZ_expect_t expectFSVector(OZ_Term t) {
    return expectVector(t, (OZ_ExpectMeth) &expectFS);
  }
};

OZ_BI_define(fset_all_disjoint, 1, 0)
{
  OZ_EXPECTED_TYPE(OZ_EM_VECT OZ_EM_FSET);
                              
  AllDisjointExpect pe;
  OZ_EXPECT(pe,0,expectFSVector);
                              
  return pe.impose(new AllDisjointPropagator(OZ_in(0)));
}
OZ_BI_end

OZ_Return AllDisjointPropagator::propagate(void)
{
  OZ_FSetVar v[_n];
  OZ_FSetVar_Iterator v_iter(_n,v);
  v_iter.read(_v);

  // first, we discover all equal variables and
  // force them to be empty

  int * is = OZ_findEqualVars(_n,_v);

  for (int i=_n;i--;) {
    int j = is[i];
    if (j>=0 && j!=i) {
      if (is[j] >= 0) {
	is[j] = -2;
	if (!(*v[j] <= fs_empty)) goto failure;
      }
      is[i]=-2;
      if (!(*v[i] <= fs_empty)) goto failure;
    }
  }

  OZ_FSetVar_Snapshot v_snap[_n];
  OZ_FSetConstraint accu;

  do {
    // 1st pass: ensure that
    // Sk is disjoint from glb(S1|...|Sk-1)
    accu = fs_empty;
    for (int i=0;i<_n;i++) {
      if (!(*v[i] != accu)) goto failure;
      accu = (accu | v[i]->getGlbSet());
    }
    // 2nd pass: ensure that
    // Sk is disjoint from glb(Sk+1|...|Sn)
    v_iter.snap(v_snap);
    accu = fs_empty;
    for (int i=_n;i--;) {
      if (!(*v[i] != accu)) goto failure;
      accu = (accu | v[i]->getGlbSet());
    }
  } while (v_iter.hasChanged(v_snap));

  // is the constraint entailed? i.e. are all sets
  // necessarily disjoint? i.e. are their lubs disjoint
  int entailed=1;
  accu=fs_empty;
  for (int i=_n;i--;) {
    OZ_FSetValue s = v[i]->getLubSet();
    if (! (accu & s).isEmpty()) entailed=0;
    accu = (accu | s);
  }
  v_iter.leave();
  return (entailed)?OZ_ENTAILED:OZ_SLEEP;
 failure:
  v_iter.fail();
  return OZ_FAILED;
}

OZ_C_proc_interface *oz_init_module(void)
{
  static OZ_C_proc_interface table[] = {
    {"all_disjoint", 1, 0, fset_all_disjoint},
    {0, 0, 0, 0}
  };
  return table;
}
