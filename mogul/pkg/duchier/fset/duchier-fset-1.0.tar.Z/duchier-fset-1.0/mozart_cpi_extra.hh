#ifndef __MOZART_CPI_EXTRA__HH__
#define __MOZART_CPI_EXTRA__HH__

#include "mozart_cpi.hh"

class OZ_FDIntVar_Snapshot {
private:
  int size;
public:
  OZ_FDIntVar_Snapshot(){};
  void operator = (OZ_FDIntVar&fd) {
    size = fd->getSize();
  }
  int operator == (OZ_FDIntVar&fd) {
    return (size==fd->getSize());
  }
  int operator != (OZ_FDIntVar&fd) {
    return !(*this == fd);
  }
};

class OZ_FSetVar_Snapshot {
private:
  int known_in,known_not_in,card_size;
public:
  OZ_FSetVar_Snapshot(){}
  void operator = (OZ_FSetVar& fs) {
    known_in     = fs->getKnownIn   ();
    known_not_in = fs->getKnownNotIn();
    card_size    = fs->getCardSize  ();
  }
  int operator == (OZ_FSetVar& fs) {
    return (known_in     == fs->getKnownIn   () &&
	    known_not_in == fs->getKnownNotIn() &&
	    card_size    == fs->getCardSize  ());
  }
  int operator != (OZ_FSetVar& fs) {
    return !(*this == fs);
  }
};

class OZ_FDIntVar_Iterator {
private:
  int size;
  OZ_FDIntVar* vect;
public:
  OZ_FDIntVar_Iterator(int s,OZ_FDIntVar* v):size(s),vect(v){}
  OZ_Boolean leave(void) {
    OZ_Boolean vars_left = OZ_FALSE;
    for (int i=size;i--;)
      vars_left |= vect[i].leave();
    return vars_left;
  }
  void fail() {
    for (int i=size;i--;) vect[i].fail();
  }
  OZ_Boolean isTouched() {
    for (int i=size;i--;)
      if (vect[i].isTouched()) return OZ_TRUE;
    return OZ_FALSE;
  }
  void ask(OZ_Term*t) {
    for (int i=size;i--;) vect[i].ask(t[i]);
  }
  int read(OZ_Term*t) {
    int n = 0;
    for (int i=size;i--;) {
      int m = vect[i].read(t[i]);
      if (m>n) n=m;
    }
    return n;
  }
  int readEncap(OZ_Term*t) {
    int n = 0;
    for (int i=size;i--;) {
      int m = vect[i].readEncap(t[i]);
      if (m>n) n=m;
    }
    return n;
  }
};

class OZ_FSetVar_Iterator {
private:
  int size;
  OZ_FSetVar* vect;
public:
  OZ_FSetVar_Iterator(int s,OZ_FSetVar* v):size(s),vect(v){}
  OZ_Boolean leave(void) {
    OZ_Boolean vars_left = OZ_FALSE;
    for (int i=size;i--;)
      vars_left |= vect[i].leave();
    return vars_left;
  }
  void fail() {
    for (int i=size;i--;) vect[i].fail();
  }
  OZ_Boolean isTouched() {
    for (int i=size;i--;)
      if (vect[i].isTouched()) return OZ_TRUE;
    return OZ_FALSE;
  }
  void ask(OZ_Term*t) {
    for (int i=size;i--;) vect[i].ask(t[i]);
  }
  void read(OZ_Term*t) {
    for (int i=size;i--;) vect[i].read(t[i]);
  }
  void readEncap(OZ_Term*t) {
    for (int i=size;i--;) vect[i].readEncap(t[i]);
  }
  void snap(OZ_FSetVar_Snapshot *s) {
    for (int i=size;i--;) s[i] = vect[i];
  }
  int hasChanged(OZ_FSetVar_Snapshot *s) {
    for (int i=size;i--;) if (s[i]!=vect[i]) return 1;
    return 0;
  }
};

#endif __MOZART_CPI_EXTRA__HH__
