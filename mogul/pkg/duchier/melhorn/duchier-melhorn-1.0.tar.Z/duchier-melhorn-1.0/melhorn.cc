#include <LEDA/graph.h>
#include <LEDA/graph_alg.h>
#include <LEDA/edge_array.h>
#include <LEDA/list.h>

enum KIND { ROOT, LEAF, INTERIOR };

bool IS_SATISFIABLE(graph& G, 
                    edge_array<bool>& is_solid, 
                    node_array<KIND>& kind,
                    list<edge>& cycle)
{
  edge e; node v;

  edge_array<node> source_node(G);
  edge_array<node> target_node(G);

  int Large = 2*G.number_of_nodes() + 1;
  // MAX_WEIGHT_MATCHING does not determine a max-weight perfect matching
  // changing the weights to L + c[e] makes a perfect matching
  
  //mymessage("construct auxiliary graph");
  GRAPH<edge,int> A; 
  forall_edges(e,G)
    { source_node[e] = A.new_node(e);
    target_node[e] = A.new_node(e);
    A.new_edge(source_node[e],target_node[e],Large);  // weight 0
    }

  forall_nodes(v,G)
    { edge e, f;  
    forall_inout_edges(e,v)
      forall_inout_edges(f,v)
      {
	if ( index(e) >= index(f) ) continue;   // consider every pair only once
	node ea = ( G.source(e) == v ?  source_node[e] : target_node[e] ) ;
	node fa = ( G.source(f) == v ?  source_node[f] : target_node[f] ) ;

	if ( kind[v] != LEAF || is_solid[e] || is_solid[f] ) 
	  A.new_edge(ea,fa,Large+1);   
      }
    }

  list<edge> M =  MAX_WEIGHT_MATCHING(A,A.edge_data());

  leda_assert(2*M.size() == A.number_of_nodes(), "matching is not perfect");

  cycle.clear();

  edge_array<bool> in_C(G,false);

  forall(e,M)
    {
      if ( A[e] == Large ) continue;
      node ua = A.source(e), va = A.target(e);
      edge e1 = A[ua], e2 = A[va];   // e2, e2 are edges in G
      if ( !in_C[e1] ) { in_C[e1] = true; cycle.append(e1); }
      if ( !in_C[e2] ) { in_C[e2] = true; cycle.append(e2); }
    }

  return ( cycle.empty() );

}

#include <mozart.h>

// {Satisfiable N [I#K] [I#J#B] ?[I#J]}
// 0=<I<N
// K 0 means ROOT, 1 means LEAF, 2 means INTERIOR
// B true means solid, false means non solid

OZ_BI_define(melhorn_satisfiable,3,1)
{
  OZ_declareInt(0,n);
  OZ_declareDetTerm(1,oznodes);
  OZ_declareDetTerm(2,ozedges);
  node int2node[n];
  KIND int2kind[n];
  GRAPH<int,bool> G;
  while (!OZ_isNil(oznodes)) {
    OZ_Term h = OZ_head(oznodes);
    int i = OZ_intToC(OZ_getArg(h,0));
    int k0 = OZ_intToC(OZ_getArg(h,1));
    KIND k = (k0==0)?ROOT:((k0==1)?LEAF:INTERIOR);
    node nn = G.new_node(i);
    int2node[i] = nn;
    int2kind[i] = k;
    oznodes = OZ_tail(oznodes);
  }
  node_array<KIND> kind(G);
  for (int i=n;i--;) {
    kind[int2node[i]] = int2kind[i];
  }
  while (!OZ_isNil(ozedges)) {
    OZ_Term h = OZ_head(ozedges);
    int i = OZ_intToC(OZ_getArg(h,0));
    int j = OZ_intToC(OZ_getArg(h,1));
    bool b = OZ_isTrue(OZ_getArg(h,2));
    G.new_edge(int2node[i],int2node[j],b);
    ozedges = OZ_tail(ozedges);
  }
  edge_array<bool> is_solid = G.edge_data();
  list<edge> cycle;
  bool sat = IS_SATISFIABLE(G,is_solid,kind,cycle);
  if (sat) { OZ_RETURN(OZ_true()); }
  edge e;
  OZ_Term l = OZ_nil();
  static OZ_Term tupleatom = OZ_atom("#");
  forall(e,cycle) {
    l = OZ_cons(OZ_pair2(OZ_int(G.inf(G.source(e))),
			 OZ_int(G.inf(G.target(e)))),
		l);
  }
  OZ_RETURN(l);
}
OZ_BI_end

OZ_C_proc_interface * oz_init_module(void)
{
  static OZ_C_proc_interface table[] = {
    {"satisfiable",3,1,melhorn_satisfiable},
    {0,0,0,0}
  };
  return table;
}

char oz_module_name[] = "Melhorn";
